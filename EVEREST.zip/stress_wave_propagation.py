# -*- coding: utf-8 -*-
"""

Copyright (c) 2022 by Lucas Lapostolle
Use under LGPL.txt library license

This file is part of EVEREST.

EVEREST is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

EVEREST is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with EVEREST. If not, see <https://www.gnu.org/licenses/>.

If you use this code, please acknowledge the source : code EVEREST, associated with the article Lucas Lapostolle, Katell Derrien, Léo Morin, Laurent Berthe and Olivier Castelnau, Fast numerical estimation of residual stresses induced by 
laser shock peening, submitted to EJM, 2022.
"""
# import of modules necessary for the code
import sys
import time
import numpy as np
import scipy.optimize
import scipy.integrate
import matplotlib.pyplot as plt

# =============================================================================
# Import of the controle file with the user-defined parameters
# =============================================================================

# The 'control_file' contains the user-defined parameters

from control_file import *

# =============================================================================
# multiple_shots: function defining the load profile with one or multiple shots
# Inputs :
#        nb_shot: integer,  number of shots required
#        i: integer, number of the current time increment
#        pressure: float,  pressure amplitude 
#        dt: float,  time increment 
# Ouput:
#        float, value of the pressure profile corresponding to the current time
#        increment 
# =============================================================================
def multiple_shots(nb_shot, i, pressure, dt):
    s_load_true = pressure*pressure_values
    t_init = np.copy(time_values)
    t_load = np.linspace(t_init[0], t_init[len(t_init)-1],  \
    int(t_init[len(t_init)-1]/dt))
    s_load_true = np.interp(t_load, t_init, s_load_true)
    ans = np.copy(s_load_true)
    for _ in range(nb_shot-1):
        ans = np.append(np.append(ans, np.zeros((int(50e-9/dt),))), \
        s_load_true)
    if i < len(ans)-1:
        return ans[i]
    return 0
# =============================================================================
# A_p_m: function calculating the matrices A_plus and A_minus for the
#         numerical scheme
# from reference "Finite Volume Methods for Hyperbolic Problems" from Randall
# Leveque,  page 81
# Input:
#        A: array,  2x2 matrix of the advection equation
# Output:
#        array, array: A_plus and A_minus matrices
# =============================================================================
def A_p_m(A):
    eig, P = np.linalg.eig(A)
    Ap = np.zeros(np.shape(A))
    Am = np.zeros(np.shape(A))
    for i in range(np.shape(A)[0]):
        Ap[i, i] = max(eig[i], 0)
        Am[i, i] = min(eig[i], 0)
    return np.dot(np.dot(P, Ap), np.linalg.inv(P)), np.dot(np.dot(P, Am),  \
    np.linalg.inv(P))

# =============================================================================
# f_lamda: function computing the lambda Lamé coefficient
# Inputs:
#    E_mod: float,  Young's modulus (MPa)
#    nu_ratio: float,  Poisson ratio
# Output:
#    float,  lambda Lamé coefficient (MPa)
# =============================================================================
def f_lamda(E_mod, nu_ratio):
    return E_mod*nu_ratio/((1+nu_ratio)*(1-2*nu_ratio))

# =============================================================================
# f_mu: function computing the mu Lamé coefficient
# Inputs:
#    E: float,  Young's modulus 
#    nu_ratio: Poisson ratio
# Ouput:   
#    float, mu Lamé coefficient 
# =============================================================================
def f_mu(E_mod, nu_ratio):
    return E_mod/(2*(1+nu_ratio))

# =============================================================================
# Stiff: function calculating the isotropic stiffness matrix in Kelvin notation
# Inputs:
#    lamda: float,  lambda Lamé coefficient
#    mu: float,  mu Lamé coefficient
# Ouputs:
#    array,  6x6 stiffness matrix
# =============================================================================
def Stiff(lamda, mu):
    Id_p = np.zeros((6, 6))
    Id_p[:3, :3] = 1
    return 2*mu*np.eye(6)+lamda*Id_p

# =============================================================================
# R_scal: function computing the JC flow stress
# Inputs:
#    dp: float,  values of the accumulated plastic strain increment over the
#        spatial domain
#    p0: float,  value of the accumulated plastic strain at the previous time
#        increment
#    sig_yield: float,  static yield stress 
#    B_param: float,  isotropic hardening parameter 
#    n_param: float,  isotropic hardening exponent
#    C_param: float,  strain rate sensitivity parameter
#    e0_param: float,  reference stain rate
#    dt: float,  time increment
# Ouputs:
#    float,  value of the plastic flow stress at a given location
# =============================================================================
def R_scal(dp, p0, sig_yield, B_param, n_param, C_param, e0_param, dt):
    if dp/dt/e0_param>1:
        return (sig_yield+B_param*(p0+dp)**n_param)*(1+C_param* \
               np.log(dp/dt/e0_param))
    return sig_yield+B_param*(p0+dp)**n_param

# =============================================================================
# R_prime_scal: funcion computing the derivative of the function R_scal with
# respect to the dp variable
# # Inputs:
#    dp: float,  values of the accumulated plastic strain increment over the
#        spatial domain
#    p0: float,  value of the accumulated plastic strain at the previous time
#        increment
#    sig_yield: float,  static yield stress
#    B_param: float,  isotropic hardening parameter
#    n_param: float,  isotropic hardening exponent
#    C_param: float,  strain rate sensitivity parameter
#    e0_param: float,  reference stain rate
#    dt: float,  time increment
# Ouputs:
#    float,  value of the plastic flow stress at a given location
# =============================================================================
def R_prime_scal(dp, p0, sig_yield, B_param, n_param, C_param, e0_param, dt):
    if dp/dt/e0_param>1:
        return B_param*n_param*(p0+dp)**(n_param-1)*(1+C_param* \
               np.log(dp/dt/e0_param))+(sig_yield+B_param*(p0+dp)**n_param)* \
               C_param/dp
    return B_param*n_param*(p0+dp)**(n_param-1)

# =============================================================================
# f_JC_scal : function computing the residual for the radial return algorithm
# Inputs:
#    dp: float,  values of the accumulated plastic strain increment over the
#        spatial domain
#    p0: float,  value of the accumulated plastic strain at the previous time
#        increment
#    sig_yield: float,  static yield stress
#    B_param: float,  isotropic hardening parameter
#    n_param: float,  isotropic hardening exponent
#    C_param: float,  strain rate sensitivity parameter
#    e0_param: float,  reference stain rate
#    dt: float,  time increment
#    vm_el: float,  values of the von Mises stress from the elastic predictor
#           step
# Output:
#    float, value of the function whose root is to find for the radial return
#    algorithm
# =============================================================================
def f_JC_scal(dp, p0, sig_yield, B_param, n_param, C_param, e0_param, dt, \
              vm_el, mu):
    return vm_el-3*mu*dp-R_scal(dp, p0, sig_yield, B_param, n_param, C_param,\
           e0_param, dt)

# =============================================================================
# f_JC_prime_scal : function computing the derivative of function f_JC_scal
# with respect to the variable dp
# Inputs:
#    dp: float,  values of the accumulated plastic strain increment over the
#        spatial domain
#    p0: float,  value of the accumulated plastic strain at the previous time
#        increment
#    sig_yield: float,  static yield stress
#    B_param: float,  isotropic hardening parameter
#    n_param: float,  isotropic hardening exponent
#    C_param: float,  strain rate sensitivity parameter
#    e0_param: float,  reference stain rate
#    dt: float,  time increment
#    vm_el: float,  values of the von Mises stress from the elastic predictor
#           step
# Output:
#    float, value of the function whose root is to find for the radial return
#    algorithm
# =============================================================================
def f_JC_prime_scal(dp, p0, sig_yield, B_param, n_param, C_param, e0_param, \
                    dt, vm_el, mu):
    return -3*mu-R_prime_scal(dp, p0, sig_yield, B_param, n_param, C_param, \
            e0_param, dt)

# =============================================================================
# sim_vec_JC : algorithm for the elastic plastic stress wave propagation
# Inuputs:
#    L_param: float,  length of the spatial domain (mm)
#    T_param: float,  duration of the simulation (s)
#    pressure: float,  amplitude of the stress signal (MPa)
#    nb_shot: integer,  number of shots in the loading signal
#    Nx: integer,  number of nodes in the simulation
#    stiff1: array,  6x6 stiffness matrix of the material
#    rho1: float,  density of the material
#    sigy1: float,  static yield stress
#    B_param: float,  isotropic hardening parameter
#    n_param: float,  isotropic hardening exponent
#    C_param: float,  strain rate sensitivity parameter
#    ep0: float,  reference stain rate
#    transmi_param: boolean,  0 for reflective boundary condition,
#                   1 for transmittive boundary condition
#    cfl_param: float,  value of the CFL parameter
#    meth_param: string,  name of the root finding method for
#                scipy.optimize.root_scalar ('ridder' by default)
# Ouputs:
#    0: array,  Nx x Nt matrix (Nt: number of time increment),
#       axial stress spatial distribution at each time increment
#    1: array,  Nx x Nt matrix (Nt: number of time increment),
#       axial velocity spatial distribution at each time increment
#    2: array,  Nx x Nt matrix (Nt: number of time increment),
#       radial stress spatial distribution at each time increment
#    3: array,  Nx x Nt matrix (Nt: number of time increment),
#       von Mises stress spatial distribution at each time increment
#    4: array,  Nx x Nt matrix (Nt: number of time increment),
#       axial plastic strain spatial distribution at each time increment
#    5: array,  Nx x Nt matrix (Nt: number of time increment),
#       accumulated spatial distribution at each time increment
#    6: array,  vector with all the times of the simulation
# =============================================================================
def sim_vec_JC(L_param, T_param, pressure, nb_shot, Nx, stiff1, rho1, sigy1, \
    B_param, n_param, C_param, ep0, transmi_param, cfl_param=1, \
    meth_param='ridder',every_incr_param=1):
# =============================================================================
#    Various material parameters are computed,  namely the Lamé coefficient and
#     bulk modulus
# =============================================================================
    lamda = stiff1[0, 1]
    mu = stiff1[5, 5]/2
    sigy = sigy1*np.ones((Nx+2, ))
# =============================================================================
#    Various quantities are computed,  namely the spatial and time increments,
#    the number of time increments necessary to complete the simulation,  the
#    elastic stress wave velocity
# =============================================================================
    dx = L_param/Nx
    cel = np.sqrt(stiff1[0, 0]/rho1)
    dt = cfl_param*dx/cel
    Nt = int(T_param/dt)
    t = np.linspace(0, T_param, Nt)
    print('Value of the time increment: ',dt)
# =============================================================================
#    The matrix A from the advection equation is computed
# =============================================================================
    A = np.zeros((2, 2))
    A[0, 1] = -stiff1[0, 0]
    A[1, 0] = -1/rho1
    Ap, Am = A_p_m(A)
# =============================================================================
#    The D matrix from the article is constructed, to optimize the computation
#    of the fields at the next time step
# =============================================================================
    M = np.zeros((Nx+2, Nx+2, 2, 2))
    D = np.zeros((2*(Nx+2), 2*(Nx+2)))
    for i in range(1, Nx+1):
        M[i, i] = (np.eye(2)+dt/dx*(-Ap+Am))
        M[i, i+1] = -Am*dt/dx
        M[i, i-1] = Ap*dt/dx
    for i in range(2*(Nx+2)):
        D[:, i] = M[:, i//2].reshape((2*(Nx+2), 2))[:, i%2]
# =============================================================================
#   A diff_x matrix is constructed to be used as an operator giving the spatial
#   derivative of a vector
# =============================================================================
    diff_x = np.zeros((Nx+2, Nx+2))
    for i in range(2, Nx):
        diff_x[i, i-1] = -1/(2*dx)
        diff_x[i, i+1] = 1/(2*dx)
    diff_x[1, 1] = -1/dx
    diff_x[1, 2] = 1/dx
    diff_x[Nx, Nx-1] = -1/dx
    diff_x[Nx, Nx] = 1/dx
# =============================================================================
#   The ans_ variable will contain the fields at every time increment,  and are
#    initialized
# =============================================================================
    ans_s = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_v = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_s22 = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_vm = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_epsp = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_eps11 = np.zeros((Nx+2, Nt//every_incr_param+1))
    ans_p = np.zeros((Nx+2, Nt//every_incr_param+1))
    u0 = np.zeros((2*(Nx+2), 1))
    s11_0 = np.zeros((Nx+2, ))
    s22_0 = np.zeros((Nx+2, ))
    epsp11_0 = np.zeros((Nx+2, ))
    p_0 = np.zeros((Nx+2, ))
    eps11_0 = np.zeros((Nx+2, ))
# =============================================================================
#    The program starts the time iteration
# =============================================================================
    for i in range(1, Nt):
        if i == int(Nt*0.05):
            sys.stdout.write('5% ')
            sys.stdout.flush()
        if i == int(Nt*0.1):
            sys.stdout.write('10% ')
            sys.stdout.flush()
        if i == int(Nt*0.15):
            sys.stdout.write('15% ')
            sys.stdout.flush()
        if i == int(Nt*0.2):
            sys.stdout.write('20% ')
            sys.stdout.flush()
        if i == int(Nt/4):
            sys.stdout.write('25% ')
            sys.stdout.flush()
        if i == int(Nt*0.3):
            sys.stdout.write('30% ')
            sys.stdout.flush()
        if i == int(Nt*0.35):
            sys.stdout.write('35% ')
            sys.stdout.flush()
        if i == int(Nt*0.4):
            sys.stdout.write('40% ')
            sys.stdout.flush()
        if i == int(Nt*0.45):
            sys.stdout.write('45% ')
            sys.stdout.flush()
        if i == int(Nt/2):
            sys.stdout.write('50% ')
            sys.stdout.flush()
        if i == int(Nt*0.55):
            sys.stdout.write('55% ')
            sys.stdout.flush()
        if i == int(Nt*0.6):
            sys.stdout.write('60% ')
            sys.stdout.flush()
        if i == int(Nt*0.65):
            sys.stdout.write('65% ')
            sys.stdout.flush()
        if i == int(Nt*0.7):
            sys.stdout.write('70% ')
            sys.stdout.flush()
        if i == int(Nt*3/4):
            sys.stdout.write('75% ')
            sys.stdout.flush()
        if i == int(Nt*0.8):
            sys.stdout.write('80% ')
            sys.stdout.flush()
        if i == int(Nt*0.85):
            sys.stdout.write('85% ')
            sys.stdout.flush()
        if i == int(Nt*0.9):
            sys.stdout.write('90% ')
            sys.stdout.flush()
        if i == int(Nt*0.95):
            sys.stdout.write('95% ')
            sys.stdout.flush()
        if i == int(Nt-1):
            sys.stdout.write('100% ')
            sys.stdout.flush()
# =============================================================================
#     A first solution is computed assuming a purely elastic evolution
# =============================================================================
        u = np.zeros((Nx+2, 2))
        u_el = np.dot(D, u0)
# =============================================================================
#     Various fields are computed and extracted in order to enventually compute
#     the von Mises stress
# =============================================================================
        s11 = u_el.reshape((Nx+2, 2))[:, 0]
        s22 = s22_0+(s11-s11_0)*lamda/(lamda+2*mu)
        s33 = np.copy(s22)
        eps11 = eps11_0+(s11-s11_0)/(lamda+2*mu)
        if i%every_incr_param==0:
            ans_eps11[:, i//every_incr_param] = eps11
        dev11 = np.add(s11, -1/3*np.add(np.add(s11, s22), s33))
        dev22 = np.add(s22, -1/3*np.add(np.add(s11, s22), s33))
        dev33 = np.add(s33, -1/3*np.add(np.add(s11, s22), s33))
        sph = 1/3*np.add(np.add(s11, s22), s33)
        vm = np.sqrt(3./2.*np.add(np.add(np.multiply(dev11, dev11), \
        np.multiply(dev22, dev22)), np.multiply(dev33, dev33)))
# =============================================================================
#  The nodes which need a plastic correction are identified
# =============================================================================
        vm_test = np.where(vm > sigy, np.ones(np.shape(vm)), \
                  np.zeros(np.shape(vm)))
        nb_correct = np.count_nonzero(vm_test)
        if np.any(vm_test == 1) == True:
            indexes = np.where(vm_test == 1)[0]
        p = np.copy(p_0)
        epsp11 = np.copy(epsp11_0)
        if i%every_incr_param==0:
            ans_epsp[:, i//every_incr_param] = np.copy(epsp11)
        if np.any(vm > sigy) == True:
# =============================================================================
# If there is no hardening,  a specific section is used where the plasticity is
# solved
# explicitely. The plastic strain increment and the corrected stress are
# computed only at the nodes where it is needed
# =============================================================================
            if B_param == 0 and C_param == 0:
                dp = np.where(vm <= sigy1, np.zeros((Nx+2, )), np.add(vm, \
                -sigy1*np.ones((Nx+2, )))/(3*mu))[np.ix_(indexes)]
                p[np.ix_(indexes)] = np.add(p[np.ix_(indexes)], dp)
            else:
# =============================================================================
# The semi-explicit radial return algorihthm is performed. The plastic
# correction is computed only for the nodes requiring it. The accumulated
# plastic strain increment is computed by finding the 0 of a non linear
# equation.
# =============================================================================
                dp = np.ones((nb_correct, ))
                for k in range(nb_correct):
                    dp_loc=0.1
                    arg=(p[indexes[k]],sigy1,B_param,n_param,C_param, \
                    ep0,dt,vm[indexes[k]],mu)
                    meth=meth_param
                    dp_loc=scipy.optimize.root_scalar(f_JC_scal,args=arg, \
                    method=meth,bracket=[np.nextafter(0,1),100], \
                    fprime=f_JC_prime_scal,x0=dp_loc,x1=dp_loc/2, \
                    xtol=1e-6).root
                    dp[k]=np.copy((dp_loc))
                    sigy[indexes[k]]=R_scal(dp_loc,p[indexes[k]],sigy1, \
                    B_param,n_param,C_param, ep0,dt)
            p[np.ix_(indexes)] = np.add(p[np.ix_(indexes)], dp)
            dev11[np.ix_(indexes)]=np.multiply(dev11[np.ix_(indexes)], \
            1-3*mu*np.divide(dp,vm[np.ix_(indexes)]))
            dev22[np.ix_(indexes)]=np.multiply(dev22[np.ix_(indexes)], \
            1-3*mu*np.divide(dp,vm[np.ix_(indexes)]))
            dev33[np.ix_(indexes)]=np.multiply(dev33[np.ix_(indexes)], \
            1-3*mu*np.divide(dp,vm[np.ix_(indexes)]))
            s11[np.ix_(indexes)] = sph[np.ix_(indexes)]+dev11[np.ix_(indexes)]
            s22[np.ix_(indexes)] = sph[np.ix_(indexes)]+dev22[np.ix_(indexes)]
            s33[np.ix_(indexes)] = sph[np.ix_(indexes)]+dev33[np.ix_(indexes)]
            vm = np.sqrt(3./2.*np.add(np.add(np.multiply(dev11, dev11), \
            np.multiply(dev22, dev22)), np.multiply(dev33, dev33)))
            dep11 = 3/2*np.multiply(dp, np.divide(dev11[np.ix_(indexes)], \
            vm[np.ix_(indexes)]))
            epsp11[np.ix_(indexes)] = np.where(dp > 0., \
            np.add(epsp11[np.ix_(indexes)], dep11), epsp11[np.ix_(indexes)])
        if i%every_incr_param==0:
            ans_p[:, i//every_incr_param] = np.copy(p)
            ans_epsp[:, i//every_incr_param] = np.copy(epsp11)
            ans_epsp[:, i//every_incr_param] = epsp11
# =============================================================================
# The boundary conditions are applied
# =============================================================================
        if transmi_param == True:
            s11[Nx+1] = np.copy(s11[Nx])
        u[:, 0] = s11
        u[:, 1] = u_el.reshape((Nx+2, 2))[:, 1]
        u = u.reshape((2*(Nx+2), 1))
        u[0][0] = multiple_shots(nb_shot, i, pressure, dt)
        u[1][0] = u[3][0]+(u[2][0]-u[0][0])/(rho1*cel)
        u[2*(Nx+2)-1][0] = (u[2*(Nx+2)-2][0]-u[2*(Nx+2)-4][0])/(rho1*cel)+\
        u[2*(Nx+2)-3][0]
        s11_0 = np.copy(s11)
        s22_0 = np.copy(s22)
        epsp11_0 = np.copy(epsp11)
        p_0 = np.copy(p)
        eps11_0 = np.copy(epsp11)
        u0 = np.copy(u.reshape((2*(Nx+2), 1)))
        if i%every_incr_param==0:
            ans_s[:, i//every_incr_param] = np.copy(s11)
            ans_v[:, i//every_incr_param] = u.reshape((Nx+2, 2))[:, 1]
            ans_vm[:, i//every_incr_param] = np.copy(vm)
            ans_s22[:, i//every_incr_param] = np.copy(s22)
    return ans_s[1:Nx+1, :Nt-1], ans_v[1:Nx+1, :Nt-1], \
           ans_s22[1:Nx+1, :Nt-1], ans_vm[1:Nx+1, :Nt-1], \
           ans_epsp[1:Nx+1, :Nt-1], ans_p[1:Nx+1, :Nt-1], t
# =============================================================================
# RS: function computing the residual stresses
# Inputs:
#    young: float,  Young's modulus
#    nu_param: float,  Poisson ratio
#    x_param: array,  vector of spatial coordinates
#    eps_p: array,  vector of eigenstrains
#    L_param: float,  length of the spatial domain (mm)
# Ouput:
#    array,  vector of residual stresses computed by 10.1243.030932405X30984
# =============================================================================
def RS(young, nu_param, x_param, eps_p, L_param):
    if np.shape(young) == () and np.shape(nu_param) == ():
        gam = (1/L_param)*scipy.integrate.simps(eps_p, x_param)
        gam1 = (1/L_param**2)*scipy.integrate.simps(np.multiply(eps_p, \
        x_param), x_param)
        return young/(1-nu_param)*(2*gam*(2-3*x_param/L_param)-6*gam1*(1-\
        2*x_param/L_param)-eps_p)
    gam1 = scipy.integrate.simps(np.divide(young, 1-nu_param), x_param)
    gam2 = scipy.integrate.simps(np.multiply(x_param, np.divide(young, \
    1-nu_param)), x_param)
    gam3 = scipy.integrate.simps(np.multiply(eps_p, np.divide(young, \
    1-nu_param)))
    gam4 = scipy.integrate.simps(np.multiply(np.power(x_param, 2), \
    np.divide(young, 1-nu_param)), x_param)
    gam5 = scipy.integrate.simps(np.multiply(np.multiply(np.multiply(x_param, \
    eps_p), np.divide(young, 1-nu_param))), x_param)
    a = L_param*(gam2*gam3-gam5*gam1)/(gam2**2-gam4*gam1)
    b = gam5/gam2-gam4/gam3*(gam2*gam3-gam5*gam1)/(gam2**2-gam4*gam1)
    return np.multiply(np.divide(young, 1-nu_param), b+a*x_param/L_param-eps_p)

if __name__ == "__main__":
    
    " All the undefined variables come from the control_file.py module "
    
# =============================================================================
#   Execution section for a template residual stress simulation.
#   To be removed or commented if not needed
# =============================================================================

#   Comment the following line to give control back to the control_file module
    from control_file_316L_RS_template import *
    
    time_values=np.loadtxt('pressure_loading.txt', skiprows = 11)[:,0]
    pressure_values=np.loadtxt('pressure_loading.txt', skiprows = 11)[:,1]
    assert e0 != 0, 'reference strain rate cannot be equal to 0'
    x = np.linspace(0, L, N)
    stiff = Stiff(f_lamda(E, nu), f_mu(E, nu))
    start = time.time()
    res_propa = sim_vec_JC(L, T, load, nb_shots, N, stiff, rho, sig_y, B, n, \
    C, e0, transmi, cfl, meth_root,every_incr)
    print('Propagation simulation time:', (time.time()-start), 's')
    sim = res_propa
    epsp = np.copy(sim[4][:, np.shape(sim[4])[1]-1])
    bfv = np.transpose(sim[1][N-1:])
    start = time.time()
    RS_1D = RS(E, nu, x, -1/2*sim[4][:, np.shape(sim[4])[1]-1], L)
    print('residual stresses computation time:', (time.time()-start), 's')
    
# =============================================================================
#   Plot section for illustration
# =============================================================================
    
    plt.figure()
    plt.plot(x,epsp)
    plt.xlabel('$x$ (mm)')
    plt.ylabel('$\\varepsilon_{p}$')
    plt.title('In-depth plastic strains')
    plt.grid(linestyle='--')
    plt.xlim(0,L)
    plt.tight_layout()
    plt.pause(0.001)
    
    plt.figure()
    plt.plot(x,RS_1D)
    plt.xlabel('$x$ (mm)')
    plt.ylabel('$\\sigma_{22}$ (MPa)')
    plt.title('In-depth residual stresses')
    plt.grid(linestyle='--')
    plt.xlim(0,L)
    plt.tight_layout()
    plt.pause(0.001)
    
# =============================================================================
#   Execution section for a template backface velocity simulation.
#   To removed be or commented if not needed
# =============================================================================
    
#   Comment the following line to give control back to the control_file module
    from control_file_316L_backface_template import *
    
    assert e0 != 0, 'reference strain rate cannot be equal to 0'
    x = np.linspace(0, L, N)
    stiff = Stiff(f_lamda(E, nu), f_mu(E, nu))
    start = time.time()
    res_propa = sim_vec_JC(L, T, load, nb_shots, N, stiff, rho, sig_y, B, n, \
    C, e0, transmi, cfl, meth_root, every_incr)
    print('Propagation simulation time:', (time.time()-start), 's')
    sim = res_propa
    epsp = np.copy(sim[4][:, np.shape(sim[4])[1]-1])
    bfv = np.transpose(sim[1][N-1:])
    start = time.time()
    RS_1D = RS(E, nu, x, -1/2*sim[4][:, np.shape(sim[4])[1]-1], L)
    print('residual stresses computation time:', (time.time()-start), 's')
    
# =============================================================================
#   Plot section for illustration
# =============================================================================
    
    plt.figure()
    plt.plot(1e9*np.linspace(0,T,np.shape(res_propa[0])[1]),1e-3*bfv)
    plt.xlabel('$t$ (ns)')
    plt.ylabel('$v_{free}$ (m/s)')
    plt.title('Backface velocity profile')
    plt.grid(linestyle='--')
    plt.xlim(0,T*1e9)
    plt.ylim(0)
    plt.tight_layout()
    plt.pause(0.001)
    
    start=time.time()
    np.savetxt('RS.out', RS_1D)
    np.savetxt('s11.out', res_propa[0])
    np.savetxt('s22.out', res_propa[2])
    np.savetxt('v1.out', res_propa[1])
    np.savetxt('epsp.out', res_propa[4])
    np.savetxt('p.out', res_propa[5])
    np.savetxt('t.out', res_propa[6])
    np.savetxt('vm.out', res_propa[3])
    print('output files creation:', (time.time()-start), 's')
    