# -*- coding: utf-8 -*-
"""

Copyright (c) 2022 by Lucas Lapostolle
Use under LGPL.txt library license

This file is part of EVEREST.

EVEREST is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

EVEREST is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with EVEREST. If not, see <https://www.gnu.org/licenses/>.

If you use this code, please acknowledge the source : code EVEREST, associated with the article Lucas Lapostolle, Katell Derrien, Léo Morin, Laurent Berthe and Olivier Castelnau, Fast numerical estimation of residual stresses induced by 
laser shock peening, submitted to EJM, 2022.
"""

" Length of the domain (mm) "
L = 10
" Duration the simulation (s) "
T = 1e-6
" Number of nodes of the simulation "
N = 1666
" Loading Amplitude (MPa) "
load = -3000		 
" Young's modulus (MPa) "
E = 210000
" Poisson ratio "
nu = 0.3
" Density (t/mm^3) "
rho = 7.8e-9  
" Yield strength (MPa) "
sig_y = 305
" B parameter of the Johnson-Cook model "
B = 441
" C parameter of the Johnson-Cook model "
C = 0.057
" n parameter of the Johnson-Cook model "
n = 0.1
" reference strain rate for the Johnson-Cook model "
e0 = 1
" number of shots "
nb_shots = 1
" Boundary condition (0 : Reflective, 1 : Transmittive) "
transmi = 0
" CFL number  "
cfl = 0.9
" Root finding method "
meth_root = 'ridder'
" Save results every x time increments "
every_incr = 1